const PAIRS = [[0.26, 0.0], [2.23, 2.08], [4.05, 4.123], [6.38, 5.28], [7.66, 7.76], [9.44, 9.76], [13.29, 12.051], [15.8, 14.211], [18.29, 16.051], [19.47, 17.234], [22.82, 20.394], [25.35, 22.634], [28.74, 25.274], [31.6, 26.997], [33.58, 28.779], [38.44, 31.101], [43.44, 32.381], [45.84, 34.807]];
const M = t => { const P = PAIRS; if (t <= P[0][0]) return P[0][1] + (t - P[0][0]); for (let i = 1; i < P.length; i++) if (t <= P[i][0]) { const [a0, b0] = P[i - 1], [a1, b1] = P[i]; return b0 + (b1 - b0) * (t - a0) / (a1 - a0); } const [a0, b0] = P[P.length - 2], [a1, b1] = P[P.length - 1]; return b1 + (t - a1) * (b1 - b0) / (a1 - a0); };
// Shared helpers, prepended to every scene file by build_motion.py
const C = { navy: '#0B1626', navy2: '#143552', white: '#F7F9FC', teal: '#2EC4B6', gold: '#FFD23F', red: '#FF4D5A', mute: '#8DA2BC', card: 'rgba(255,255,255,0.07)', green: '#3DDC84' };

function bg(ctx, t) {
  const X = ctx.X;
  const g = X.createLinearGradient(0, 0, 0, 1920); g.addColorStop(0, C.navy); g.addColorStop(1, C.navy2);
  X.fillStyle = g; X.fillRect(0, 0, 1080, 1920);
  X.save();
  for (let i = 0; i < 46; i++) {
    const x = ctx.hash01(i, 1) * 1080, sp = 12 + 30 * ctx.hash01(i, 3);
    const y = (((ctx.hash01(i, 2) * 1920 - t * sp) % 1920) + 1920) % 1920;
    X.globalAlpha = 0.05 + 0.1 * ctx.hash01(i, 4); X.fillStyle = C.teal;
    X.beginPath(); X.arc(x, y, 2 + 4 * ctx.hash01(i, 5), 0, 6.2832); X.fill();
  }
  X.restore();
  ctx.text(X, 'مسودة للمراجعة', 1030, 200, { family: 'body', weight: 400, size: 30, color: 'rgba(255,255,255,0.4)', align: 'right' });
}

// Kinetic line: each word rises from its baseline at the moment it is spoken; hot words pop in colour.
function line(ctx, t, id, y, o = {}) {
  const { X } = ctx; const ws = ctx.wordsOf(id); const span = ctx.lineSpan(id);
  const out = o.out != null ? ctx.at(t, o.out, o.out + 0.25, 'cubicIn') : 0;
  if (out >= 1 || t < ws[0].s - 0.12) return null;
  const L = ctx.text.layout(X, span.text, { family: o.family || 'body', weight: o.weight || 900, size: o.size || 88, maxWidth: o.maxWidth || 900, lineHeight: 1.25 });
  return ctx.text.drawLayout(X, L, 540, y, {
    align: 'center', color: o.color || C.white, perWord: (i, word) => {
      const w = ws[i] || ws[ws.length - 1];
      const k = ctx.at(t, w.s - 0.1, w.s + 0.22, 'expoOut');
      if (k <= 0) return { alpha: 0 };
      const hot = (o.hot || []).some(h => word.includes(h));
      const pop = hot ? ctx.E.backOut(ctx.prog(t, w.s, w.s + 0.4)) : 1;
      return { clipUp: hot ? undefined : 1, dy: (1 - k) * 90 - out * 70, alpha: 1 - out, color: hot ? (o.hotColor || C.gold) : undefined,
        scale: hot ? 0.5 + 0.5 * pop : 1, shadow: { blur: 22, y: 6, color: 'rgba(0,0,0,0.45)' } };
    }
  });
}

function rrect(X, x, y, w, h, r) { X.beginPath(); X.roundRect(x, y, w, h, r); }
function card(X, x, y, w, h, a = 1, fill = C.card, stroke = 'rgba(255,255,255,0.14)') {
  if (a <= 0) return; X.save(); X.globalAlpha *= a; X.fillStyle = fill; rrect(X, x, y, w, h, 28); X.fill();
  X.strokeStyle = stroke; X.lineWidth = 3; X.stroke(); X.restore();
}
function cross(X, cx, cy, r, k, col = C.red, lw = 22) {
  if (k <= 0) return; const a = Math.min(1, k * 2), b = Math.max(0, k * 2 - 1);
  X.save(); X.strokeStyle = col; X.lineWidth = lw; X.lineCap = 'round'; X.shadowColor = 'rgba(0,0,0,0.4)'; X.shadowBlur = 16;
  X.beginPath(); X.moveTo(cx - r, cy - r); X.lineTo(cx - r + 2 * r * a, cy - r + 2 * r * a); X.stroke();
  if (b > 0) { X.beginPath(); X.moveTo(cx + r, cy - r); X.lineTo(cx + r - 2 * r * b, cy - r + 2 * r * b); X.stroke(); }
  X.restore();
}
function check(X, cx, cy, r, k, col = C.green, lw = 20) {
  if (k <= 0) return; const p = [[cx - r, cy], [cx - r * 0.3, cy + r * 0.7], [cx + r, cy - r * 0.7]];
  const a = Math.min(1, k * 2.5), b = Math.max(0, (k - 0.4) / 0.6);
  X.save(); X.strokeStyle = col; X.lineWidth = lw; X.lineCap = 'round'; X.lineJoin = 'round';
  X.beginPath(); X.moveTo(p[0][0], p[0][1]); X.lineTo(p[0][0] + (p[1][0] - p[0][0]) * a, p[0][1] + (p[1][1] - p[0][1]) * a);
  if (b > 0) X.lineTo(p[1][0] + (p[2][0] - p[1][0]) * b, p[1][1] + (p[2][1] - p[1][1]) * b);
  X.stroke(); X.restore();
}
function shake(t, t0, amp = 22) {
  const d = t - t0; if (d < 0 || d > 0.6) return [0, 0];
  const e = Math.exp(-d * 8); return [amp * e * Math.sin(d * 90), amp * e * Math.cos(d * 77)];
}
// Rubber-stamp slam: big → settles with a slight tilt.
function stamp(ctx, X, str, cx, cy, t0, t, o = {}) {
  const k = ctx.prog(t, t0, t0 + 0.22); if (k <= 0) return;
  const s = o.size || 150, sc = 2.2 - 1.2 * ctx.E.expoOut(k), col = o.color || C.red;
  X.save(); X.translate(cx, cy); X.rotate(o.rot ?? -0.07); X.scale(sc, sc); X.globalAlpha *= Math.min(1, k * 3) * (o.alpha ?? 1);
  X.font = `900 ${s}px "Tajawal"`; const tw = X.measureText(str).width;
  X.strokeStyle = col; X.lineWidth = 12; rrect(X, -tw / 2 - 40, -s * 0.95, tw + 80, s * 1.35, 24); X.stroke();
  ctx.text(X, str, 0, s * 0.1, { family: 'body', weight: 900, size: s, color: col });
  X.restore();
}
function ivBag(ctx, X, cx, top, s, t, label = 'IV') {
  const w = 240 * s, h = 320 * s, x = cx - w / 2;
  X.save(); X.lineWidth = 8 * s; X.strokeStyle = 'rgba(255,255,255,0.85)'; X.lineCap = 'round';
  X.beginPath(); X.arc(cx, top - 18 * s, 18 * s, Math.PI, 0); X.stroke();
  rrect(X, x, top, w, h, 40 * s); X.fillStyle = 'rgba(255,255,255,0.06)'; X.fill(); X.stroke();
  X.save(); rrect(X, x + 8 * s, top + 8 * s, w - 16 * s, h - 16 * s, 32 * s); X.clip();
  const lvl = top + h * 0.35 + Math.sin(t * 2.2) * 6 * s;
  X.fillStyle = 'rgba(46,196,182,0.55)'; X.beginPath(); X.moveTo(x, lvl);
  for (let i = 0; i <= 20; i++) X.lineTo(x + w * i / 20, lvl + Math.sin(i * 0.9 + t * 4) * 5 * s);
  X.lineTo(x + w, top + h); X.lineTo(x, top + h); X.closePath(); X.fill(); X.restore();
  ctx.text(X, label, cx, top + h * 0.66, { family: 'num', weight: 900, size: 72 * s, color: '#FFFFFF', dir: 'ltr' });
  X.beginPath(); X.moveTo(cx, top + h); X.lineTo(cx, top + h + 30 * s); X.stroke();
  rrect(X, cx - 22 * s, top + h + 30 * s, 44 * s, 80 * s, 12 * s); X.stroke();
  const ph = (t * 1.4) % 1; X.fillStyle = C.teal; X.globalAlpha = 1 - ph * 0.6;
  X.beginPath(); X.arc(cx, top + h + 46 * s + ph * 50 * s, 7 * s, 0, 6.2832); X.fill(); X.globalAlpha = 1;
  X.beginPath(); X.moveTo(cx, top + h + 110 * s); X.bezierCurveTo(cx, top + h + 200 * s, cx + 90 * s, top + h + 170 * s, cx + 90 * s, top + h + 260 * s); X.stroke();
  X.restore();
}
function pill(ctx, X, str, cx, cy, a, rot = 0, ltr = false) {
  if (a <= 0) return; X.save(); X.translate(cx, cy); X.rotate(rot); X.globalAlpha *= a;
  X.font = `700 50px "${ltr ? 'Inter' : 'Tajawal'}"`; const tw = X.measureText(str).width;
  rrect(X, -tw / 2 - 34, -50, tw + 68, 100, 50); X.fillStyle = 'rgba(46,196,182,0.18)'; X.fill();
  X.strokeStyle = C.teal; X.lineWidth = 4; X.stroke();
  ctx.text(X, str, 0, 17, { family: ltr ? 'num' : 'body', weight: 700, size: 50, color: C.white, dir: ltr ? 'ltr' : 'rtl' });
  X.restore();
}
// IV vitamins & NAD: kinetic scenes. Every cue reads its time from the spoken word (ctx.wordTime).
const WT = (ctx, id, i) => ctx.wordTime(id, i).s;

// s1 — hook: IV bag drips; «NAD» and «شباب؟» pop
MOTION.scene({ id: 's1', draw(t, lt, ctx) {
  const { X } = ctx; bg(ctx, t);
  const k = ctx.at(t, 0.05, 0.9, 'expoOut'), nad = ctx.prog(t, WT(ctx, 'l2', 1), WT(ctx, 'l2', 1) + 0.5);
  X.save(); X.translate(540, 300); X.scale(0.7 + 0.3 * k, 0.7 + 0.3 * k); X.globalAlpha = k;
  if (nad > 0) { X.save(); X.globalAlpha = 0.35 * Math.sin(Math.PI * Math.min(1, nad * 1.4)) + 0.15 * nad; X.fillStyle = C.teal;
    X.beginPath(); X.arc(0, 160, 260, 0, 6.2832); X.filter = 'blur(40px)'; X.fill(); X.restore(); }
  ivBag(ctx, X, 0, 0, 1.1, t); X.restore();
  line(ctx, t, 'l1', 960, { size: 80, hot: ['الفيتامينات'], hotColor: C.teal });
  line(ctx, t, 'l2', 1250, { size: 118, hot: ['NAD', 'شباب'] });
} });

// s2 — «وشو وضعها؟» → stamp «كلام فاضي» with a jolt → «ولا فيه منها أي فايدة»
MOTION.scene({ id: 's2', draw(t, lt, ctx) {
  const { X } = ctx; bg(ctx, t);
  const ts = WT(ctx, 'l4', 3), [dx, dy] = shake(t, ts, 26);
  X.save(); X.translate(dx, dy);
  const q = ctx.at(t, WT(ctx, 'l3', 0) - 0.1, WT(ctx, 'l3', 0) + 0.4, 'backOut') * (1 - ctx.at(t, WT(ctx, 'l4', 0) - 0.2, WT(ctx, 'l4', 0) + 0.2));
  if (q > 0) ctx.text(X, '؟', 540, 1150, { family: 'display', size: 620, color: C.teal, alpha: 0.18 * q });
  line(ctx, t, 'l3', 820, { size: 104, hot: ['بالضبط'], hotColor: C.teal, out: WT(ctx, 'l4', 0) - 0.25 });
  line(ctx, t, 'l4', 560, { size: 90 });
  stamp(ctx, X, 'كلام فاضي', 540, 930, ts, t, { size: 170 });
  line(ctx, t, 'l5', 1330, { size: 92, hot: ['أي', 'فايدة'] });
  X.restore();
} });

// s3 — skin card ✗, ageing card ✗
MOTION.scene({ id: 's3', draw(t, lt, ctx) {
  const { X } = ctx; bg(ctx, t);
  const t1 = WT(ctx, 'l6', 2), t2 = WT(ctx, 'l6', 5);
  const a1 = ctx.at(t, t1 - 0.25, t1 + 0.2, 'backOut'), a2 = ctx.at(t, t2 - 0.25, t2 + 0.2, 'backOut');
  // right card: skin (face)
  X.save(); X.translate(760, 760); X.scale(a1, a1); X.translate(-760, -760);
  card(X, 570, 470, 380, 580, a1);
  X.save(); X.globalAlpha *= a1; X.strokeStyle = C.white; X.lineWidth = 10; X.lineCap = 'round';
  X.beginPath(); X.arc(760, 700, 120, 0, 6.2832); X.stroke();
  X.fillStyle = C.white; [[715, 670], [805, 670]].forEach(([x, y]) => { X.beginPath(); X.arc(x, y, 12, 0, 6.2832); X.fill(); });
  X.beginPath(); X.arc(760, 715, 55, 0.25, Math.PI - 0.25); X.stroke(); X.restore();
  ctx.text(X, 'البشرة', 760, 960, { family: 'body', weight: 900, size: 72, color: C.white, alpha: a1 });
  X.restore();
  // left card: ageing (hourglass)
  X.save(); X.translate(320, 760); X.scale(a2, a2); X.translate(-320, -760);
  card(X, 130, 470, 380, 580, a2);
  X.save(); X.globalAlpha *= a2; X.strokeStyle = C.white; X.lineWidth = 10; X.lineJoin = 'round';
  X.beginPath(); X.moveTo(240, 580); X.lineTo(400, 580); X.lineTo(320, 700); X.lineTo(400, 820); X.lineTo(240, 820); X.lineTo(320, 700); X.closePath(); X.stroke();
  const sand = (t * 0.25) % 1; X.fillStyle = C.gold;
  X.beginPath(); X.moveTo(240 + 80 * sand * 0.6, 820 - 0); X.lineTo(400 - 80 * sand * 0.6, 820); X.lineTo(320, 820 - 70 * sand); X.closePath(); X.fill();
  X.restore();
  ctx.text(X, 'الشيخوخة', 320, 960, { family: 'body', weight: 900, size: 72, color: C.white, alpha: a2 });
  X.restore();
  cross(X, 760, 760, 150, ctx.at(t, t1 + 0.35, t1 + 0.75), C.red, 26);
  cross(X, 320, 760, 150, ctx.at(t, t2 + 0.45, t2 + 0.85), C.red, 26);
  line(ctx, t, 'l6', 1330, { size: 84 });
} });

// s4 — «انتعاش ≠ فايدة»
MOTION.scene({ id: 's4', draw(t, lt, ctx) {
  const { X } = ctx; bg(ctx, t);
  const tA = WT(ctx, 'l7', 2), tNe = WT(ctx, 'l8', 0), tB = WT(ctx, 'l8', 3);
  const a = ctx.at(t, tA - 0.1, tA + 0.35, 'backOut'), n = ctx.at(t, tNe - 0.05, tNe + 0.3, 'backOut'), b = ctx.at(t, tB - 0.1, tB + 0.35, 'backOut');
  if (a > 0) {
    X.save(); X.translate(820, 640); X.scale(a, a);
    for (let i = 0; i < 8; i++) { const ang = i * 0.785 + t * 0.6, r0 = 150 + 12 * Math.sin(t * 6 + i);
      X.strokeStyle = C.teal; X.globalAlpha = 0.6; X.lineWidth = 8; X.lineCap = 'round';
      X.beginPath(); X.moveTo(Math.cos(ang) * r0, Math.sin(ang) * r0); X.lineTo(Math.cos(ang) * (r0 + 40), Math.sin(ang) * (r0 + 40)); X.stroke(); }
    X.globalAlpha = 1; ctx.text(X, 'انتعاش', 0, 30, { family: 'body', weight: 900, size: 86, color: C.teal }); X.restore();
  }
  if (n > 0) { X.save(); X.translate(540, 620); X.scale(n, n); ctx.text(X, '≠', 0, 50, { family: 'num', weight: 900, size: 200, color: C.red, dir: 'ltr' }); X.restore(); }
  if (b > 0) { X.save(); X.translate(250, 640); X.scale(b, b); ctx.text(X, 'فايدة', 0, 30, { family: 'body', weight: 900, size: 100, color: C.gold }); X.restore(); }
  line(ctx, t, 'l7', 1180, { size: 86, hot: ['بانتعاش'], hotColor: C.teal, out: tNe - 0.25 });
  line(ctx, t, 'l8', 1180, { size: 86, hot: ['يفيد'], out: WT(ctx, 'l9', 0) - 0.2 });
  line(ctx, t, 'l9', 1180, { size: 96, hot: ['الشيخوخة'], hotColor: C.white });
} });

// s5 — weak / moderate / strong study cards, then all crossed: «ما لها أي إثبات»
MOTION.scene({ id: 's5', draw(t, lt, ctx) {
  const { X } = ctx; bg(ctx, t);
  const labels = ['دراسات ضعيفة', 'دراسات متوسطة', 'دراسات قوية'], tx = WT(ctx, 'l11', 3);
  labels.forEach((lab, i) => {
    const ti = WT(ctx, 'l10', i + 1), k = ctx.at(t, ti - 0.2, ti + 0.25, 'expoOut'); if (k <= 0) return;
    const y = 420 + i * 210, x = 140 + (1 - k) * 300;
    card(X, x, y, 800, 170, k);
    ctx.text(X, lab, x + 760, y + 108, { family: 'body', weight: 900, size: 64, color: C.white, align: 'right', alpha: k });
    for (let j = 0; j < 3; j++) { X.save(); X.globalAlpha = k * (j <= i ? 1 : 0.2); X.fillStyle = C.teal;
      rrect(X, x + 50 + j * 50, y + 125 - (j + 1) * 30, 34, (j + 1) * 30, 6); X.fill(); X.restore(); }
    cross(X, x + 125, y + 85, 55, ctx.at(t, tx + i * 0.15, tx + i * 0.15 + 0.35), C.red, 18);
  });
  line(ctx, t, 'l10', 1250, { size: 80, out: WT(ctx, 'l11', 0) - 0.2 });
  line(ctx, t, 'l11', 1250, { size: 92, hot: ['إثبات'], hotColor: C.red });
} });

// s6 — vitamin-level gauge: deficiency → topped up → «فقط»; «مش بشكل عام» ✗
MOTION.scene({ id: 's6', draw(t, lt, ctx) {
  const { X } = ctx; bg(ctx, t);
  const tLow = WT(ctx, 'l12', 5), tFill = WT(ctx, 'l13', 0), tOnly = WT(ctx, 'l13', 2), tGen = WT(ctx, 'l14', 3);
  const show = ctx.at(t, M(25.3), M(25.9), 'expoOut');
  ctx.text(X, 'مستوى الفيتامين بالجسم', 540, 470, { family: 'body', weight: 700, size: 52, color: C.mute, alpha: show });
  const x0 = 140, w = 800, y = 540;
  card(X, x0, y, w, 90, show, 'rgba(255,255,255,0.06)');
  X.save(); X.globalAlpha = show * 0.35; X.fillStyle = C.green; rrect(X, x0 + w * 0.6, y, w * 0.25, 90, 0); X.fill(); X.restore();
  ctx.text(X, 'الطبيعي', x0 + w * 0.725, y + 150, { family: 'body', weight: 700, size: 40, color: C.green, alpha: show });
  const lvl = ctx.kf(t, [[M(25.3), 0.5], [tLow, 0.5], [tLow + 0.5, 0.15, 'cubicOut'], [tFill, 0.15], [tFill + 1.0, 0.72, 'cubicInOut']]);
  const col = lvl < 0.4 ? C.red : C.green;
  X.save(); X.globalAlpha = show; X.fillStyle = col; rrect(X, x0 + 8, y + 8, (w - 16) * lvl, 74, 20); X.fill(); X.restore();
  const lowA = ctx.at(t, tLow, tLow + 0.3) * (1 - ctx.at(t, tFill, tFill + 0.3));
  ctx.text(X, 'نقص', x0 + w * 0.12, y - 30, { family: 'body', weight: 900, size: 56, color: C.red, alpha: lowA });
  const [dx, dy] = shake(t, tOnly, 14); X.save(); X.translate(dx, dy);
  stamp(ctx, X, 'فقط', 540, 930, tOnly, t, { size: 140, color: C.gold, alpha: 1 - ctx.at(t, tGen - 0.6, tGen - 0.2) });
  X.restore();
  const g = ctx.at(t, tGen - 0.3, tGen + 0.2, 'backOut');
  if (g > 0) { X.save(); X.translate(540, 880); X.scale(g, g); pill(ctx, X, 'للكل؟', 0, 0, 1); X.restore(); cross(X, 540, 880, 70, ctx.at(t, tGen + 0.2, tGen + 0.55), C.red, 16); }
  line(ctx, t, 'l12', 1260, { size: 82, hot: ['نقص', 'معيّن'], hotColor: C.red, out: tFill - 0.2 });
  line(ctx, t, 'l13', 1260, { size: 92, hot: ['فقط'], out: WT(ctx, 'l14', 0) - 0.2 });
  line(ctx, t, 'l14', 1260, { size: 92, hot: ['أبداً'], hotColor: C.red });
} });

// s7 — marketing buzzwords float in, then drop away on «كلام فاضي»
MOTION.scene({ id: 's7', draw(t, lt, ctx) {
  const { X } = ctx; bg(ctx, t);
  const tf = WT(ctx, 'l15', 5), [dx, dy] = shake(t, tf, 26);
  const P = [['شباب دائم', 760, 430, -0.06, 0], ['Anti-aging', 320, 560, 0.05, 1], ['طاقة فورية', 700, 700, 0.04, 0],
             ['Detox', 300, 830, -0.05, 1], ['بشرة نضرة', 720, 960, -0.03, 0], ['مناعة خارقة', 340, 1080, 0.06, 0]];
  X.save(); X.translate(dx, dy);
  P.forEach(([s, x, y, r, ltr], i) => {
    const ti = M(33.75) + i * 0.35, a = ctx.at(t, ti, ti + 0.35, 'backOut'), f = Math.max(0, t - tf);
    const fy = 900 * f * f + 200 * f * (i % 2 ? 1 : 0.6), fr = r + f * (i % 2 ? 2.2 : -2.2);
    pill(ctx, X, s, x, y + fy + Math.sin(t * 2 + i) * 8, a * (1 - ctx.at(t, tf + 0.3, tf + 0.9)), fr, !!ltr);
  });
  stamp(ctx, X, 'كلام فاضي', 540, 760, tf, t, { size: 170 });
  line(ctx, t, 'l15', 1330, { size: 90, hot: ['يتسوّق'], hotColor: C.teal });
  X.restore();
} });

// s8 — «أساس علاج النقص»: ✓ food, ✓ sleep
MOTION.scene({ id: 's8', draw(t, lt, ctx) {
  const { X } = ctx; bg(ctx, t);
  line(ctx, t, 'l16', 520, { size: 104, hot: ['النقص'], hotColor: C.gold });
  const items = [['التغذية الصحيحة', WT(ctx, 'l17', 0), 'plate'], ['النوم الكافي', WT(ctx, 'l17', 2), 'moon']];
  const ghost = ctx.at(t, M(40.8), M(41.6));
  items.forEach(([lab, ti, icon], i) => {
    const y = 720 + i * 260, k = ctx.at(t, ti - 0.2, ti + 0.25, 'backOut');
    if (k <= 0) { if (ghost > 0) { X.save(); X.globalAlpha = 0.5 * ghost; X.setLineDash([18, 14]); X.strokeStyle = 'rgba(255,255,255,0.3)'; X.lineWidth = 3; rrect(X, 140, y, 800, 200, 28); X.stroke(); X.restore(); } return; }
    X.save(); X.translate(540, y + 100); X.scale(k, k); X.translate(-540, -(y + 100));
    card(X, 140, y, 800, 200, 1, 'rgba(61,220,132,0.10)', 'rgba(61,220,132,0.5)');
    ctx.text(X, lab, 900, y + 122, { family: 'body', weight: 900, size: 62, color: C.white, align: 'right' });
    X.strokeStyle = C.white; X.lineWidth = 8; X.lineCap = 'round';
    if (icon === 'plate') { X.beginPath(); X.arc(290, y + 100, 44, 0, 6.2832); X.stroke(); X.beginPath(); X.arc(290, y + 100, 24, 0, 6.2832); X.stroke();
      X.beginPath(); X.moveTo(228, y + 62); X.lineTo(228, y + 138); X.stroke(); X.beginPath(); X.moveTo(352, y + 62); X.lineTo(352, y + 138); X.stroke(); }
    else { X.fillStyle = C.gold; X.beginPath(); X.arc(290, y + 100, 44, 0, 6.2832); X.fill(); X.fillStyle = '#163A57';
      X.beginPath(); X.arc(310, y + 86, 40, 0, 6.2832); X.fill(); }
    X.restore();
    check(X, 190, y + 100, 26, ctx.at(t, ti + 0.25, ti + 0.6), C.green, 14);
  });
} });

// s9 — IV ✗ «عن طريق الوريد», then recap card
MOTION.scene({ id: 's9', draw(t, lt, ctx) {
  const { X } = ctx; bg(ctx, t);
  const tv = WT(ctx, 'l18', 5), tEnd = ctx.lineSpan('l18').e + 0.5, [dx, dy] = shake(t, tv, 24);
  const fade = 1 - ctx.at(t, tEnd - 0.2, tEnd + 0.3);
  if (fade > 0) {
    X.save(); X.globalAlpha = fade; X.translate(dx, dy);
    X.save(); X.translate(540, 330); X.globalAlpha *= 1 - 0.5 * ctx.at(t, tv, tv + 0.4); ivBag(ctx, X, 0, 0, 1.0, t); X.restore();
    cross(X, 540, 560, 220, ctx.at(t, tv, tv + 0.4), C.red, 34);
    line(ctx, t, 'l18', 1180, { size: 86, hot: ['الوريد'], hotColor: C.red, });
    X.restore();
  }
  // recap
  const r = ctx.at(t, tEnd, tEnd + 0.5, 'expoOut'); if (r <= 0) return;
  X.save(); X.globalAlpha = r;
  ctx.text(X, 'الخلاصة', 540, 470, { family: 'body', weight: 700, size: 52, color: C.teal });
  ctx.text(X, 'محاليل الفيتامينات و NAD', 540, 590, { family: 'body', weight: 900, size: 78, color: C.white });
  const rows = [['ما ترجعك شباب', C.red, 'x'], ['تفيد بس اللي عنده نقص', C.green, 'v'], ['الأساس: تغذية صحيحة ونوم كافي', C.gold, 'v']];
  rows.forEach(([s, col, m], i) => {
    const k = ctx.at(t, tEnd + 0.4 + i * 0.45, tEnd + 0.8 + i * 0.45, 'expoOut'); if (k <= 0) return;
    const y = 720 + i * 190;
    card(X, 120 + (1 - k) * 200, y, 840, 150, k);
    ctx.text(X, s, 860 + (1 - k) * 200, y + 95, { family: 'body', weight: 900, size: 46, color: C.white, align: 'right', maxWidth: 600, alpha: k });
    if (m === 'x') cross(X, 210, y + 75, 32, ctx.at(t, tEnd + 0.7 + i * 0.45, tEnd + 1.0 + i * 0.45), col, 14);
    else check(X, 210, y + 75, 34, ctx.at(t, tEnd + 0.7 + i * 0.45, tEnd + 1.0 + i * 0.45), col, 14);
  });
  X.restore();
} });
