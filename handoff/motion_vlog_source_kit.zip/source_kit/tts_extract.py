"""Extract an ElevenLabs with-timestamps response (saved Zapier result) to mp3 + alignment, and report pace."""
import json, sys, base64, re, subprocess
src, o = sys.argv[1], sys.argv[2]
b = json.loads(open(src, encoding='utf-8').read())["results"][0]["body"]
open(o + ".mp3", "wb").write(base64.b64decode(b["audio_base64"]))
json.dump(b["alignment"], open(o + ".align.json", "w"), ensure_ascii=False)
a = b["alignment"]; text = "".join(a["characters"]); n = len([w for w in text.split() if any(c.isalpha() for c in w)])
d = float(subprocess.run(["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "csv=p=0", o + ".mp3"], capture_output=True, text=True).stdout)
log = subprocess.run(["ffmpeg", "-hide_banner", "-i", o + ".mp3", "-af", "silencedetect=noise=-35dB:d=0.2", "-f", "null", "-"], capture_output=True, text=True).stderr
st = [float(x) for x in re.findall(r"silence_start: ([\d.]+)", log)]; en = [float(x) for x in re.findall(r"silence_end: ([\d.]+)", log)]
sil = sum(e - s for s, e in zip(st, en))
print(f"{n} words, {d:.1f}s -> {n/d*60:.0f} WPM; pauses: {len(en)} totalling {sil:.1f}s; speech-only {n/(d-sil)*60:.0f} WPM")
