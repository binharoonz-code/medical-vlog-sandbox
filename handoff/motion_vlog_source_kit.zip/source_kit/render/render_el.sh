#!/bin/bash
# Render prebuilt projects and add the final ElevenLabs voice. Usage: render_el.sh name...
S=$SCRATCH
R=$S/ext/video-ad-editor/video-ad-editor/motion
mkdir -p $S/out/videos
for n in "$@"; do
  P=$S/proj/$n
  (cd $R && CHROME=/opt/pw-browsers/chromium-1194/chrome-linux/chrome node render.js $P all --fresh > $S/proj/$n.render.log 2>&1) || { echo "FAIL render $n"; continue; }
  ffmpeg -hide_banner -loglevel error -y -i $P/renders/video.mp4 -i $S/final_audio/$n.wav -map 0:v -map 1:a -c:v copy -c:a aac -b:a 192k -ar 48000 -shortest -movflags +faststart $S/out/videos/${n}_v4voice.mp4 && rm -rf $P/renders/frames && echo "DONE $n"
done
