#!/bin/bash
# 4K (2160x3840) masters of all seven, with the final ElevenLabs voice.
S=$SCRATCH
R=$S/ext/video-ad-editor/video-ad-editor/motion
mkdir -p $S/out/4k
for n in 07_pimple 02_phone_hemorrhoids 03_iv_nad 01_ice_water 06_caffeine 04_weekend_sleep 05_jet_lag; do
  P=$S/proj/$n; [ $n = 03_iv_nad ] && P=$S/motion_ivnad
  (cd $R && CHROME=/opt/pw-browsers/chromium-1194/chrome-linux/chrome node render.js $P all --fresh --scale 2 > $S/proj/$n.4k.log 2>&1) || { echo "FAIL $n"; continue; }
  V=$(ls -t $P/renders/video*.mp4 | head -1)
  ffmpeg -hide_banner -loglevel error -y -i $V -i $S/final_audio/$n.wav -map 0:v -map 1:a -c:v copy -af apad -c:a aac -b:a 256k -ar 48000 -shortest -movflags +faststart $S/out/4k/${n}_motion_4K.mp4 && rm -rf $P/renders/frames* && echo "DONE $n $(ffprobe -v error -select_streams v -show_entries stream=width,height -of csv=p=0 $S/out/4k/${n}_motion_4K.mp4) $(du -h $S/out/4k/${n}_motion_4K.mp4 | cut -f1)"
done
