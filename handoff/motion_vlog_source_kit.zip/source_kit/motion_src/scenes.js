// IV vitamins & NAD: kinetic scenes. Every cue reads its time from the spoken word (ctx.wordTime).
const WT = (ctx, id, i) => ctx.wordTime(id, i).s;

// s1 — hook: IV bag drips; «NAD» and «شباب؟» pop
MOTION.scene({ id: 's1', draw(t, lt, ctx) {
  const { X } = ctx; bg(ctx, t);
  const k = ctx.at(t, 0.05, 0.9, 'expoOut'), nad = ctx.prog(t, WT(ctx, 'l2', 1), WT(ctx, 'l2', 1) + 0.5);
  X.save(); X.translate(540, 300); X.scale(0.7 + 0.3 * k, 0.7 + 0.3 * k); X.globalAlpha = k;
  if (nad > 0) { X.save(); X.globalAlpha = 0.35 * Math.sin(Math.PI * Math.min(1, nad * 1.4)) + 0.15 * nad; X.fillStyle = C.teal;
    X.beginPath(); X.arc(0, 160, 260, 0, 6.2832); X.filter = 'blur(40px)'; X.fill(); X.restore(); }
  ivBag(ctx, X, 0, 0, 1.1, t); X.restore();
  line(ctx, t, 'l1', 960, { size: 80, hot: ['الفيتامينات'], hotColor: C.teal });
  line(ctx, t, 'l2', 1250, { size: 118, hot: ['NAD', 'شباب'] });
} });

// s2 — «وشو وضعها؟» → stamp «كلام فاضي» with a jolt → «ولا فيه منها أي فايدة»
MOTION.scene({ id: 's2', draw(t, lt, ctx) {
  const { X } = ctx; bg(ctx, t);
  const ts = WT(ctx, 'l4', 3), [dx, dy] = shake(t, ts, 26);
  X.save(); X.translate(dx, dy);
  const q = ctx.at(t, WT(ctx, 'l3', 0) - 0.1, WT(ctx, 'l3', 0) + 0.4, 'backOut') * (1 - ctx.at(t, WT(ctx, 'l4', 0) - 0.2, WT(ctx, 'l4', 0) + 0.2));
  if (q > 0) ctx.text(X, '؟', 540, 1150, { family: 'display', size: 620, color: C.teal, alpha: 0.18 * q });
  line(ctx, t, 'l3', 820, { size: 104, hot: ['بالضبط'], hotColor: C.teal, out: WT(ctx, 'l4', 0) - 0.25 });
  line(ctx, t, 'l4', 560, { size: 90 });
  stamp(ctx, X, 'كلام فاضي', 540, 930, ts, t, { size: 170 });
  line(ctx, t, 'l5', 1330, { size: 92, hot: ['أي', 'فايدة'] });
  X.restore();
} });

// s3 — skin card ✗, ageing card ✗
MOTION.scene({ id: 's3', draw(t, lt, ctx) {
  const { X } = ctx; bg(ctx, t);
  const t1 = WT(ctx, 'l6', 2), t2 = WT(ctx, 'l6', 5);
  const a1 = ctx.at(t, t1 - 0.25, t1 + 0.2, 'backOut'), a2 = ctx.at(t, t2 - 0.25, t2 + 0.2, 'backOut');
  // right card: skin (face)
  X.save(); X.translate(760, 760); X.scale(a1, a1); X.translate(-760, -760);
  card(X, 570, 470, 380, 580, a1);
  X.save(); X.globalAlpha *= a1; X.strokeStyle = C.white; X.lineWidth = 10; X.lineCap = 'round';
  X.beginPath(); X.arc(760, 700, 120, 0, 6.2832); X.stroke();
  X.fillStyle = C.white; [[715, 670], [805, 670]].forEach(([x, y]) => { X.beginPath(); X.arc(x, y, 12, 0, 6.2832); X.fill(); });
  X.beginPath(); X.arc(760, 715, 55, 0.25, Math.PI - 0.25); X.stroke(); X.restore();
  ctx.text(X, 'البشرة', 760, 960, { family: 'body', weight: 900, size: 72, color: C.white, alpha: a1 });
  X.restore();
  // left card: ageing (hourglass)
  X.save(); X.translate(320, 760); X.scale(a2, a2); X.translate(-320, -760);
  card(X, 130, 470, 380, 580, a2);
  X.save(); X.globalAlpha *= a2; X.strokeStyle = C.white; X.lineWidth = 10; X.lineJoin = 'round';
  X.beginPath(); X.moveTo(240, 580); X.lineTo(400, 580); X.lineTo(320, 700); X.lineTo(400, 820); X.lineTo(240, 820); X.lineTo(320, 700); X.closePath(); X.stroke();
  const sand = (t * 0.25) % 1; X.fillStyle = C.gold;
  X.beginPath(); X.moveTo(240 + 80 * sand * 0.6, 820 - 0); X.lineTo(400 - 80 * sand * 0.6, 820); X.lineTo(320, 820 - 70 * sand); X.closePath(); X.fill();
  X.restore();
  ctx.text(X, 'الشيخوخة', 320, 960, { family: 'body', weight: 900, size: 72, color: C.white, alpha: a2 });
  X.restore();
  cross(X, 760, 760, 150, ctx.at(t, t1 + 0.35, t1 + 0.75), C.red, 26);
  cross(X, 320, 760, 150, ctx.at(t, t2 + 0.45, t2 + 0.85), C.red, 26);
  line(ctx, t, 'l6', 1330, { size: 84 });
} });

// s4 — «انتعاش ≠ فايدة»
MOTION.scene({ id: 's4', draw(t, lt, ctx) {
  const { X } = ctx; bg(ctx, t);
  const tA = WT(ctx, 'l7', 2), tNe = WT(ctx, 'l8', 0), tB = WT(ctx, 'l8', 3);
  const a = ctx.at(t, tA - 0.1, tA + 0.35, 'backOut'), n = ctx.at(t, tNe - 0.05, tNe + 0.3, 'backOut'), b = ctx.at(t, tB - 0.1, tB + 0.35, 'backOut');
  if (a > 0) {
    X.save(); X.translate(820, 640); X.scale(a, a);
    for (let i = 0; i < 8; i++) { const ang = i * 0.785 + t * 0.6, r0 = 150 + 12 * Math.sin(t * 6 + i);
      X.strokeStyle = C.teal; X.globalAlpha = 0.6; X.lineWidth = 8; X.lineCap = 'round';
      X.beginPath(); X.moveTo(Math.cos(ang) * r0, Math.sin(ang) * r0); X.lineTo(Math.cos(ang) * (r0 + 40), Math.sin(ang) * (r0 + 40)); X.stroke(); }
    X.globalAlpha = 1; ctx.text(X, 'انتعاش', 0, 30, { family: 'body', weight: 900, size: 86, color: C.teal }); X.restore();
  }
  if (n > 0) { X.save(); X.translate(540, 620); X.scale(n, n); ctx.text(X, '≠', 0, 50, { family: 'num', weight: 900, size: 200, color: C.red, dir: 'ltr' }); X.restore(); }
  if (b > 0) { X.save(); X.translate(250, 640); X.scale(b, b); ctx.text(X, 'فايدة', 0, 30, { family: 'body', weight: 900, size: 100, color: C.gold }); X.restore(); }
  line(ctx, t, 'l7', 1180, { size: 86, hot: ['بانتعاش'], hotColor: C.teal, out: tNe - 0.25 });
  line(ctx, t, 'l8', 1180, { size: 86, hot: ['يفيد'], out: WT(ctx, 'l9', 0) - 0.2 });
  line(ctx, t, 'l9', 1180, { size: 96, hot: ['الشيخوخة'], hotColor: C.white });
} });

// s5 — weak / moderate / strong study cards, then all crossed: «ما لها أي إثبات»
MOTION.scene({ id: 's5', draw(t, lt, ctx) {
  const { X } = ctx; bg(ctx, t);
  const labels = ['دراسات ضعيفة', 'دراسات متوسطة', 'دراسات قوية'], tx = WT(ctx, 'l11', 3);
  labels.forEach((lab, i) => {
    const ti = WT(ctx, 'l10', i + 1), k = ctx.at(t, ti - 0.2, ti + 0.25, 'expoOut'); if (k <= 0) return;
    const y = 420 + i * 210, x = 140 + (1 - k) * 300;
    card(X, x, y, 800, 170, k);
    ctx.text(X, lab, x + 760, y + 108, { family: 'body', weight: 900, size: 64, color: C.white, align: 'right', alpha: k });
    for (let j = 0; j < 3; j++) { X.save(); X.globalAlpha = k * (j <= i ? 1 : 0.2); X.fillStyle = C.teal;
      rrect(X, x + 50 + j * 50, y + 125 - (j + 1) * 30, 34, (j + 1) * 30, 6); X.fill(); X.restore(); }
    cross(X, x + 125, y + 85, 55, ctx.at(t, tx + i * 0.15, tx + i * 0.15 + 0.35), C.red, 18);
  });
  line(ctx, t, 'l10', 1250, { size: 80, out: WT(ctx, 'l11', 0) - 0.2 });
  line(ctx, t, 'l11', 1250, { size: 92, hot: ['إثبات'], hotColor: C.red });
} });

// s6 — vitamin-level gauge: deficiency → topped up → «فقط»; «مش بشكل عام» ✗
MOTION.scene({ id: 's6', draw(t, lt, ctx) {
  const { X } = ctx; bg(ctx, t);
  const tLow = WT(ctx, 'l12', 5), tFill = WT(ctx, 'l13', 0), tOnly = WT(ctx, 'l13', 2), tGen = WT(ctx, 'l14', 3);
  const show = ctx.at(t, 25.3, 25.9, 'expoOut');
  ctx.text(X, 'مستوى الفيتامين بالجسم', 540, 470, { family: 'body', weight: 700, size: 52, color: C.mute, alpha: show });
  const x0 = 140, w = 800, y = 540;
  card(X, x0, y, w, 90, show, 'rgba(255,255,255,0.06)');
  X.save(); X.globalAlpha = show * 0.35; X.fillStyle = C.green; rrect(X, x0 + w * 0.6, y, w * 0.25, 90, 0); X.fill(); X.restore();
  ctx.text(X, 'الطبيعي', x0 + w * 0.725, y + 150, { family: 'body', weight: 700, size: 40, color: C.green, alpha: show });
  const lvl = ctx.kf(t, [[25.3, 0.5], [tLow, 0.5], [tLow + 0.5, 0.15, 'cubicOut'], [tFill, 0.15], [tFill + 1.4, 0.72, 'cubicInOut']]);
  const col = lvl < 0.4 ? C.red : C.green;
  X.save(); X.globalAlpha = show; X.fillStyle = col; rrect(X, x0 + 8, y + 8, (w - 16) * lvl, 74, 20); X.fill(); X.restore();
  const lowA = ctx.at(t, tLow, tLow + 0.3) * (1 - ctx.at(t, tFill, tFill + 0.3));
  ctx.text(X, 'نقص', x0 + w * 0.12, y - 30, { family: 'body', weight: 900, size: 56, color: C.red, alpha: lowA });
  const [dx, dy] = shake(t, tOnly, 14); X.save(); X.translate(dx, dy);
  stamp(ctx, X, 'فقط', 540, 930, tOnly, t, { size: 140, color: C.gold, alpha: 1 - ctx.at(t, tGen - 0.6, tGen - 0.2) });
  X.restore();
  const g = ctx.at(t, tGen - 0.3, tGen + 0.2, 'backOut');
  if (g > 0) { X.save(); X.translate(540, 880); X.scale(g, g); pill(ctx, X, 'للكل؟', 0, 0, 1); X.restore(); cross(X, 540, 880, 70, ctx.at(t, tGen + 0.2, tGen + 0.55), C.red, 16); }
  line(ctx, t, 'l12', 1260, { size: 82, hot: ['نقص', 'معيّن'], hotColor: C.red, out: tFill - 0.2 });
  line(ctx, t, 'l13', 1260, { size: 92, hot: ['فقط'], out: WT(ctx, 'l14', 0) - 0.2 });
  line(ctx, t, 'l14', 1260, { size: 92, hot: ['أبداً'], hotColor: C.red });
} });

// s7 — marketing buzzwords float in, then drop away on «كلام فاضي»
MOTION.scene({ id: 's7', draw(t, lt, ctx) {
  const { X } = ctx; bg(ctx, t);
  const tf = WT(ctx, 'l15', 5), [dx, dy] = shake(t, tf, 26);
  const P = [['شباب دائم', 760, 430, -0.06, 0], ['Anti-aging', 320, 560, 0.05, 1], ['طاقة فورية', 700, 700, 0.04, 0],
             ['Detox', 300, 830, -0.05, 1], ['بشرة نضرة', 720, 960, -0.03, 0], ['مناعة خارقة', 340, 1080, 0.06, 0]];
  X.save(); X.translate(dx, dy);
  P.forEach(([s, x, y, r, ltr], i) => {
    const ti = 33.75 + i * 0.5, a = ctx.at(t, ti, ti + 0.35, 'backOut'), f = Math.max(0, t - tf);
    const fy = 900 * f * f + 200 * f * (i % 2 ? 1 : 0.6), fr = r + f * (i % 2 ? 2.2 : -2.2);
    pill(ctx, X, s, x, y + fy + Math.sin(t * 2 + i) * 8, a * (1 - ctx.at(t, tf + 0.3, tf + 0.9)), fr, !!ltr);
  });
  stamp(ctx, X, 'كلام فاضي', 540, 760, tf, t, { size: 170 });
  line(ctx, t, 'l15', 1330, { size: 90, hot: ['يتسوّق'], hotColor: C.teal });
  X.restore();
} });

// s8 — «أساس علاج النقص»: ✓ food, ✓ sleep
MOTION.scene({ id: 's8', draw(t, lt, ctx) {
  const { X } = ctx; bg(ctx, t);
  line(ctx, t, 'l16', 520, { size: 104, hot: ['النقص'], hotColor: C.gold });
  const items = [['التغذية الصحيحة', WT(ctx, 'l17', 0), 'plate'], ['النوم الكافي', WT(ctx, 'l17', 2), 'moon']];
  const ghost = ctx.at(t, 40.8, 41.6);
  items.forEach(([lab, ti, icon], i) => {
    const y = 720 + i * 260, k = ctx.at(t, ti - 0.2, ti + 0.25, 'backOut');
    if (k <= 0) { if (ghost > 0) { X.save(); X.globalAlpha = 0.5 * ghost; X.setLineDash([18, 14]); X.strokeStyle = 'rgba(255,255,255,0.3)'; X.lineWidth = 3; rrect(X, 140, y, 800, 200, 28); X.stroke(); X.restore(); } return; }
    X.save(); X.translate(540, y + 100); X.scale(k, k); X.translate(-540, -(y + 100));
    card(X, 140, y, 800, 200, 1, 'rgba(61,220,132,0.10)', 'rgba(61,220,132,0.5)');
    ctx.text(X, lab, 900, y + 122, { family: 'body', weight: 900, size: 62, color: C.white, align: 'right' });
    X.strokeStyle = C.white; X.lineWidth = 8; X.lineCap = 'round';
    if (icon === 'plate') { X.beginPath(); X.arc(290, y + 100, 44, 0, 6.2832); X.stroke(); X.beginPath(); X.arc(290, y + 100, 24, 0, 6.2832); X.stroke();
      X.beginPath(); X.moveTo(228, y + 62); X.lineTo(228, y + 138); X.stroke(); X.beginPath(); X.moveTo(352, y + 62); X.lineTo(352, y + 138); X.stroke(); }
    else { X.fillStyle = C.gold; X.beginPath(); X.arc(290, y + 100, 44, 0, 6.2832); X.fill(); X.fillStyle = '#163A57';
      X.beginPath(); X.arc(310, y + 86, 40, 0, 6.2832); X.fill(); }
    X.restore();
    check(X, 190, y + 100, 26, ctx.at(t, ti + 0.25, ti + 0.6), C.green, 14);
  });
} });

// s9 — IV ✗ «عن طريق الوريد», coins on «فلوس زايدة», then recap card
MOTION.scene({ id: 's9', draw(t, lt, ctx) {
  const { X } = ctx; bg(ctx, t);
  const tv = WT(ctx, 'l18', 5), tm = WT(ctx, 'l19', 2), tEnd = 50.3, [dx, dy] = shake(t, tv, 24);
  const fade = 1 - ctx.at(t, tEnd - 0.2, tEnd + 0.3);
  if (fade > 0) {
    X.save(); X.globalAlpha = fade; X.translate(dx, dy);
    X.save(); X.translate(540, 330); X.globalAlpha *= 1 - 0.5 * ctx.at(t, tv, tv + 0.4); ivBag(ctx, X, 0, 0, 1.0, t); X.restore();
    cross(X, 540, 560, 220, ctx.at(t, tv, tv + 0.4), C.red, 34);
    line(ctx, t, 'l18', 1180, { size: 86, hot: ['الوريد'], hotColor: C.red, out: WT(ctx, 'l19', 0) - 0.2 });
    line(ctx, t, 'l19', 1180, { size: 100, hot: ['فلوس', 'زايدة'] });
    for (let i = 0; i < 14; i++) {
      const t0 = tm + i * 0.09, d = t - t0; if (d <= 0) continue;
      const x = 180 + ctx.hash01(i, 9) * 720, yy = Math.min(1450 - (i % 4) * 26, -80 + 1500 * d * d + 300 * d);
      X.save(); X.translate(x, yy); X.scale(1, 0.92); X.fillStyle = C.gold; X.beginPath(); X.arc(0, 0, 40, 0, 6.2832); X.fill();
      X.strokeStyle = '#C99A00'; X.lineWidth = 6; X.beginPath(); X.arc(0, 0, 27, 0, 6.2832); X.stroke(); X.restore();
    }
    X.restore();
  }
  // recap
  const r = ctx.at(t, tEnd, tEnd + 0.5, 'expoOut'); if (r <= 0) return;
  X.save(); X.globalAlpha = r;
  ctx.text(X, 'الخلاصة', 540, 470, { family: 'body', weight: 700, size: 52, color: C.teal });
  ctx.text(X, 'محاليل الفيتامينات و NAD', 540, 590, { family: 'body', weight: 900, size: 78, color: C.white });
  const rows = [['ما ترجعك شباب', C.red, 'x'], ['تفيد بس اللي عنده نقص', C.green, 'v'], ['الأساس: تغذية صحيحة ونوم كافي', C.gold, 'v']];
  rows.forEach(([s, col, m], i) => {
    const k = ctx.at(t, tEnd + 0.4 + i * 0.45, tEnd + 0.8 + i * 0.45, 'expoOut'); if (k <= 0) return;
    const y = 720 + i * 190;
    card(X, 120 + (1 - k) * 200, y, 840, 150, k);
    ctx.text(X, s, 860 + (1 - k) * 200, y + 95, { family: 'body', weight: 900, size: 46, color: C.white, align: 'right', maxWidth: 600, alpha: k });
    if (m === 'x') cross(X, 210, y + 75, 32, ctx.at(t, tEnd + 0.7 + i * 0.45, tEnd + 1.0 + i * 0.45), col, 14);
    else check(X, 210, y + 75, 34, ctx.at(t, tEnd + 0.7 + i * 0.45, tEnd + 1.0 + i * 0.45), col, 14);
  });
  X.restore();
} });
